package com.app.simple2;

public class AdvSpellChecker implements SpellChecker{
   public AdvSpellChecker(){
      System.out.println("Inside adv SpellChecker constructor." );
   }

   public void checkSpelling() {
      System.out.println("Inside  adv checkSpelling." );
   }
   
}