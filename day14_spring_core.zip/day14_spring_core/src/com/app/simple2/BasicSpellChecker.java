package com.app.simple2;

public class BasicSpellChecker implements SpellChecker{
   public BasicSpellChecker(){
      System.out.println("Inside Basic SpellChecker constructor." );
   }

   public void checkSpelling() {
      System.out.println("Inside  basic checkSpelling." );
   }
   
}