package com.app.simple2;

public interface SpellChecker {
	void checkSpelling();
}
