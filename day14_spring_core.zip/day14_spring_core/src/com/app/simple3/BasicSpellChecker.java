package com.app.simple3;

public class BasicSpellChecker {
   public BasicSpellChecker(){
      System.out.println("Inside Basic SpellChecker constructor." );
   }

   public void checkSpelling() {
      System.out.println("Inside  basic checkSpelling." );
   }
   
}