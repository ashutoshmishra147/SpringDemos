package com.auto.wiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test{
public static void main(String[] args) {

	ApplicationContext context = new ClassPathXmlApplicationContext("Bean.xml");
	Employee emp = context.getBean("emp", Employee.class);
	emp.setEid(101);
	emp.setEname("Ashutosh");
	emp.showEmployeeDetails();
	}
}